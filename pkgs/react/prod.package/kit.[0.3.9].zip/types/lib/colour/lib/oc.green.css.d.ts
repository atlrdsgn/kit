export {};
//# sourceMappingURL=oc.green.css.d.ts.map