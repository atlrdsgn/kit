export { Chip, type ChipProps } from './chip';
//# sourceMappingURL=index.d.ts.map