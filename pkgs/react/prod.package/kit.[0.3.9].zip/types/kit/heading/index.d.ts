export { Heading, type HeadingProps } from './heading';
//# sourceMappingURL=index.d.ts.map