export { Button, type ButtonProps } from './button';
//# sourceMappingURL=index.d.ts.map