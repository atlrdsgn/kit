export { Grid, type GridProps, } from './grid';
//# sourceMappingURL=index.d.ts.map