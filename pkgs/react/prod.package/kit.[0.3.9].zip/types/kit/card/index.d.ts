export { Card, type CardProps } from './card';
//# sourceMappingURL=index.d.ts.map