export { PassLink, type PassLinkProps } from './passlink';
//# sourceMappingURL=index.d.ts.map