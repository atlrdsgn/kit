export { Flex, type FlexProps } from './flex';
//# sourceMappingURL=index.d.ts.map