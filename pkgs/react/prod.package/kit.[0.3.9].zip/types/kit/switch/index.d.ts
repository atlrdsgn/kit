export { Switch, type SwitchProps } from './switch';
//# sourceMappingURL=index.d.ts.map