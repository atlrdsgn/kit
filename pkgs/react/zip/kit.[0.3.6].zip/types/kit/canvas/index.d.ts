export { Canvas, type CanvasProps } from './canvas';
//# sourceMappingURL=index.d.ts.map