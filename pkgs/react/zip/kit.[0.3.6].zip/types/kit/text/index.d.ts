export { Text, type TextProps } from './text';
//# sourceMappingURL=index.d.ts.map