export { Section, type SectionProps } from './section';
//# sourceMappingURL=index.d.ts.map