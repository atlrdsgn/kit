export { Box, Rect, type DivProps, } from './rect';
//# sourceMappingURL=index.d.ts.map