export { Container, type ContainerProps } from './container';
//# sourceMappingURL=index.d.ts.map