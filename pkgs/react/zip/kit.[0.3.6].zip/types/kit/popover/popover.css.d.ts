export declare const popoverTrigger: string;
export declare const popoverContent: string;
export declare const popoverArrow: string;
export declare const popoverClose: string;
//# sourceMappingURL=popover.css.d.ts.map