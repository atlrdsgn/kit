/*! 
    AtelierKit© v0.3.5. 
    Copyright © 2023 atlrdsgn®. All rights reserved.
    
    see https://docs.atlrdsgn.com for more information.
    @atlrdsgn/kit is licensed under the MIT License.
     */
import J from "react";
var Ee = ie, ie = { media: { breakpoints: { small: "var(--jolfc71)", medium: "var(--jolfc72)", large: "var(--jolfc73)", xlarge: "var(--jolfc74)" }, colorModes: { LIGHT: "var(--jolfc75)", DARK: "var(--jolfc76)" } }, font: { family: { system: "var(--jolfc77)", mono: "var(--jolfc78)" }, heading: { H1: "var(--jolfc79)", H2: "var(--jolfc7a)", H3: "var(--jolfc7b)", H4: "var(--jolfc7c)", H5: "var(--jolfc7d)", H6: "var(--jolfc7e)" }, size: { MINI: "var(--jolfc7f)", XS: "var(--jolfc7g)", SM: "var(--jolfc7h)", MD: "var(--jolfc7i)", LG: "var(--jolfc7j)", XL: "var(--jolfc7k)", XXL: "var(--jolfc7l)", "3XL": "var(--jolfc7m)", "4XL": "var(--jolfc7n)", "5XL": "var(--jolfc7o)", "6XL": "var(--jolfc7p)", "7XL": "var(--jolfc7q)", "8XL": "var(--jolfc7r)", "9XL": "var(--jolfc7s)" }, lineheight: { MINI: "var(--jolfc7t)", XS: "var(--jolfc7u)", SM: "var(--jolfc7v)", MD: "var(--jolfc7w)", LG: "var(--jolfc7x)", XL: "var(--jolfc7y)", XXL: "var(--jolfc7z)", "3XL": "var(--jolfc710)", "4XL": "var(--jolfc711)", "5XL": "var(--jolfc712)", "6XL": "var(--jolfc713)", "7XL": "var(--jolfc714)", "8XL": "var(--jolfc715)", "9XL": "var(--jolfc716)" }, weight: { SUPRLITE: "var(--jolfc717)", ULTRALITE: "var(--jolfc718)", LITE: "var(--jolfc719)", REGULAR: "var(--jolfc71a)", MEDIUM: "var(--jolfc71b)", SEMIBOLD: "var(--jolfc71c)", BOLD: "var(--jolfc71d)", HEAVY: "var(--jolfc71e)", BLACK: "var(--jolfc71f)" } }, radii: { ZERO: "var(--jolfc71g)", NO: "var(--jolfc71h)", DF: "var(--jolfc71i)", XS: "var(--jolfc71j)", SM: "var(--jolfc71k)", MD: "var(--jolfc71l)", LG: "var(--jolfc71m)", XL: "var(--jolfc71n)", XXL: "var(--jolfc71o)", PILL: "var(--jolfc71p)" }, space: { ZERO: "var(--jolfc71q)", NO: "var(--jolfc71r)", DF: "var(--jolfc71s)", APX: "var(--jolfc71t)", BPX: "var(--jolfc71u)", CPX: "var(--jolfc71v)", DPX: "var(--jolfc71w)", EPX: "var(--jolfc71x)", FPX: "var(--jolfc71y)", GPX: "var(--jolfc71z)", HPX: "var(--jolfc720)", IPX: "var(--jolfc721)", JPX: "var(--jolfc722)", KPX: "var(--jolfc723)", LPX: "var(--jolfc724)", MPX: "var(--jolfc725)", NPX: "var(--jolfc726)", OPX: "var(--jolfc727)", PPX: "var(--jolfc728)", QPX: "var(--jolfc729)", RPX: "var(--jolfc72a)", SPX: "var(--jolfc72b)", TPX: "var(--jolfc72c)", UPX: "var(--jolfc72d)", VPX: "var(--jolfc72e)", WPX: "var(--jolfc72f)", XPX: "var(--jolfc72g)", YPX: "var(--jolfc72h)", ZPX: "var(--jolfc72i)" }, z: { indice: { ZERO: "var(--jolfc72j)", DF: "var(--jolfc72k)", LOW: "var(--jolfc72l)", MED: "var(--jolfc72m)", HIGH: "var(--jolfc72n)", TOP: "var(--jolfc72o)", MAX: "var(--jolfc72p)" } }, shadow: { NO: "var(--jolfc72q)", DF: "var(--jolfc72r)", LOW: "var(--jolfc72s)", MED: "var(--jolfc72t)", HIGH: "var(--jolfc72u)" }, color: { transparent: "var(--jolfc72v)", current: "var(--jolfc72w)", white: "var(--jolfc72x)", black: "var(--jolfc72y)", jade0: "var(--jolfc72z)", jade1: "var(--jolfc730)", jade2: "var(--jolfc731)", jade3: "var(--jolfc732)", jade4: "var(--jolfc733)", jade5: "var(--jolfc734)", jade6: "var(--jolfc735)", jade7: "var(--jolfc736)", jade8: "var(--jolfc737)", jade9: "var(--jolfc738)", jade10: "var(--jolfc739)", jade11: "var(--jolfc73a)", jade12: "var(--jolfc73b)", sapphire0: "var(--jolfc73c)", sapphire1: "var(--jolfc73d)", sapphire2: "var(--jolfc73e)", sapphire3: "var(--jolfc73f)", sapphire4: "var(--jolfc73g)", sapphire5: "var(--jolfc73h)", sapphire6: "var(--jolfc73i)", sapphire7: "var(--jolfc73j)", sapphire8: "var(--jolfc73k)", sapphire9: "var(--jolfc73l)", sapphire10: "var(--jolfc73m)", sapphire11: "var(--jolfc73n)", sapphire12: "var(--jolfc73o)", peach0: "var(--jolfc73p)", peach1: "var(--jolfc73q)", peach2: "var(--jolfc73r)", peach3: "var(--jolfc73s)", peach4: "var(--jolfc73t)", peach5: "var(--jolfc73u)", peach6: "var(--jolfc73v)", peach7: "var(--jolfc73w)", peach8: "var(--jolfc73x)", peach9: "var(--jolfc73y)", peach10: "var(--jolfc73z)", peach11: "var(--jolfc740)", peach12: "var(--jolfc741)", carbon0: "var(--jolfc742)", carbon1: "var(--jolfc743)", carbon2: "var(--jolfc744)", carbon3: "var(--jolfc745)", carbon4: "var(--jolfc746)", carbon5: "var(--jolfc747)", carbon6: "var(--jolfc748)", carbon7: "var(--jolfc749)", carbon8: "var(--jolfc74a)", carbon9: "var(--jolfc74b)", carbon10: "var(--jolfc74c)", carbon11: "var(--jolfc74d)", carbon12: "var(--jolfc74e)", slate0: "var(--jolfc74f)", slate1: "var(--jolfc74g)", slate2: "var(--jolfc74h)", slate3: "var(--jolfc74i)", slate4: "var(--jolfc74j)", slate5: "var(--jolfc74k)", slate6: "var(--jolfc74l)", slate7: "var(--jolfc74m)", slate8: "var(--jolfc74n)", slate9: "var(--jolfc74o)", slate10: "var(--jolfc74p)", slate11: "var(--jolfc74q)", slate12: "var(--jolfc74r)", azure0: "var(--jolfc74s)", azure1: "var(--jolfc74t)", azure2: "var(--jolfc74u)", azure3: "var(--jolfc74v)", azure4: "var(--jolfc74w)", azure5: "var(--jolfc74x)", azure6: "var(--jolfc74y)", azure7: "var(--jolfc74z)", azure8: "var(--jolfc750)", azure9: "var(--jolfc751)", azure10: "var(--jolfc752)", azure11: "var(--jolfc753)", azure12: "var(--jolfc754)", cherry0: "var(--jolfc755)", cherry1: "var(--jolfc756)", cherry2: "var(--jolfc757)", cherry3: "var(--jolfc758)", cherry4: "var(--jolfc759)", cherry5: "var(--jolfc75a)", cherry6: "var(--jolfc75b)", cherry7: "var(--jolfc75c)", cherry8: "var(--jolfc75d)", cherry9: "var(--jolfc75e)", cherry10: "var(--jolfc75f)", cherry11: "var(--jolfc75g)", cherry12: "var(--jolfc75h)", lime0: "var(--jolfc75i)", lime1: "var(--jolfc75j)", lime2: "var(--jolfc75k)", lime3: "var(--jolfc75l)", lime4: "var(--jolfc75m)", lime5: "var(--jolfc75n)", lime6: "var(--jolfc75o)", lime7: "var(--jolfc75p)", lime8: "var(--jolfc75q)", lime9: "var(--jolfc75r)", lime10: "var(--jolfc75s)", lime11: "var(--jolfc75t)", lime12: "var(--jolfc75u)", lemon0: "var(--jolfc75v)", lemon1: "var(--jolfc75w)", lemon2: "var(--jolfc75x)", lemon3: "var(--jolfc75y)", lemon4: "var(--jolfc75z)", lemon5: "var(--jolfc760)", lemon6: "var(--jolfc761)", lemon7: "var(--jolfc762)", lemon8: "var(--jolfc763)", lemon9: "var(--jolfc764)", lemon10: "var(--jolfc765)", lemon11: "var(--jolfc766)", lemon12: "var(--jolfc767)" } }, K = { exports: {} }, k = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Rr;
function ue() {
  if (Rr)
    return k;
  Rr = 1;
  var o = J, n = Symbol.for("react.element"), i = Symbol.for("react.fragment"), l = Object.prototype.hasOwnProperty, p = o.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, R = { key: !0, ref: !0, __self: !0, __source: !0 };
  function _(g, s, P) {
    var h, E = {}, T = null, F = null;
    P !== void 0 && (T = "" + P), s.key !== void 0 && (T = "" + s.key), s.ref !== void 0 && (F = s.ref);
    for (h in s)
      l.call(s, h) && !R.hasOwnProperty(h) && (E[h] = s[h]);
    if (g && g.defaultProps)
      for (h in s = g.defaultProps, s)
        E[h] === void 0 && (E[h] = s[h]);
    return { $$typeof: n, type: g, key: T, ref: F, props: E, _owner: p.current };
  }
  return k.Fragment = i, k.jsx = _, k.jsxs = _, k;
}
var A = {};
/**
 * @license React
 * react-jsx-runtime.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Pr;
function ve() {
  return Pr || (Pr = 1, process.env.NODE_ENV !== "production" && function() {
    var o = J, n = Symbol.for("react.element"), i = Symbol.for("react.portal"), l = Symbol.for("react.fragment"), p = Symbol.for("react.strict_mode"), R = Symbol.for("react.profiler"), _ = Symbol.for("react.provider"), g = Symbol.for("react.context"), s = Symbol.for("react.forward_ref"), P = Symbol.for("react.suspense"), h = Symbol.for("react.suspense_list"), E = Symbol.for("react.memo"), T = Symbol.for("react.lazy"), F = Symbol.for("react.offscreen"), Z = Symbol.iterator, xr = "@@iterator";
    function Sr(r) {
      if (r === null || typeof r != "object")
        return null;
      var e = Z && r[Z] || r[xr];
      return typeof e == "function" ? e : null;
    }
    var S = o.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
    function m(r) {
      {
        for (var e = arguments.length, a = new Array(e > 1 ? e - 1 : 0), t = 1; t < e; t++)
          a[t - 1] = arguments[t];
        Cr("error", r, a);
      }
    }
    function Cr(r, e, a) {
      {
        var t = S.ReactDebugCurrentFrame, u = t.getStackAddendum();
        u !== "" && (e += "%s", a = a.concat([u]));
        var v = a.map(function(c) {
          return String(c);
        });
        v.unshift("Warning: " + e), Function.prototype.apply.call(console[r], console, v);
      }
    }
    var Xr = !1, Dr = !1, Lr = !1, kr = !1, Ar = !1, Q;
    Q = Symbol.for("react.module.reference");
    function Fr(r) {
      return !!(typeof r == "string" || typeof r == "function" || r === l || r === R || Ar || r === p || r === P || r === h || kr || r === F || Xr || Dr || Lr || typeof r == "object" && r !== null && (r.$$typeof === T || r.$$typeof === E || r.$$typeof === _ || r.$$typeof === g || r.$$typeof === s || // This needs to include all possible module reference object
      // types supported by any Flight configuration anywhere since
      // we don't know which Flight build this will end up being used
      // with.
      r.$$typeof === Q || r.getModuleId !== void 0));
    }
    function Ir(r, e, a) {
      var t = r.displayName;
      if (t)
        return t;
      var u = e.displayName || e.name || "";
      return u !== "" ? a + "(" + u + ")" : a;
    }
    function rr(r) {
      return r.displayName || "Context";
    }
    function O(r) {
      if (r == null)
        return null;
      if (typeof r.tag == "number" && m("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof r == "function")
        return r.displayName || r.name || null;
      if (typeof r == "string")
        return r;
      switch (r) {
        case l:
          return "Fragment";
        case i:
          return "Portal";
        case R:
          return "Profiler";
        case p:
          return "StrictMode";
        case P:
          return "Suspense";
        case h:
          return "SuspenseList";
      }
      if (typeof r == "object")
        switch (r.$$typeof) {
          case g:
            var e = r;
            return rr(e) + ".Consumer";
          case _:
            var a = r;
            return rr(a._context) + ".Provider";
          case s:
            return Ir(r, r.render, "ForwardRef");
          case E:
            var t = r.displayName || null;
            return t !== null ? t : O(r.type) || "Memo";
          case T: {
            var u = r, v = u._payload, c = u._init;
            try {
              return O(c(v));
            } catch {
              return null;
            }
          }
        }
      return null;
    }
    var x = Object.assign, D = 0, er, ar, or, tr, nr, lr, fr;
    function cr() {
    }
    cr.__reactDisabledLog = !0;
    function Mr() {
      {
        if (D === 0) {
          er = console.log, ar = console.info, or = console.warn, tr = console.error, nr = console.group, lr = console.groupCollapsed, fr = console.groupEnd;
          var r = {
            configurable: !0,
            enumerable: !0,
            value: cr,
            writable: !0
          };
          Object.defineProperties(console, {
            info: r,
            log: r,
            warn: r,
            error: r,
            group: r,
            groupCollapsed: r,
            groupEnd: r
          });
        }
        D++;
      }
    }
    function zr() {
      {
        if (D--, D === 0) {
          var r = {
            configurable: !0,
            enumerable: !0,
            writable: !0
          };
          Object.defineProperties(console, {
            log: x({}, r, {
              value: er
            }),
            info: x({}, r, {
              value: ar
            }),
            warn: x({}, r, {
              value: or
            }),
            error: x({}, r, {
              value: tr
            }),
            group: x({}, r, {
              value: nr
            }),
            groupCollapsed: x({}, r, {
              value: lr
            }),
            groupEnd: x({}, r, {
              value: fr
            })
          });
        }
        D < 0 && m("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
      }
    }
    var V = S.ReactCurrentDispatcher, Y;
    function I(r, e, a) {
      {
        if (Y === void 0)
          try {
            throw Error();
          } catch (u) {
            var t = u.stack.trim().match(/\n( *(at )?)/);
            Y = t && t[1] || "";
          }
        return `
` + Y + r;
      }
    }
    var U = !1, M;
    {
      var Nr = typeof WeakMap == "function" ? WeakMap : Map;
      M = new Nr();
    }
    function ir(r, e) {
      if (!r || U)
        return "";
      {
        var a = M.get(r);
        if (a !== void 0)
          return a;
      }
      var t;
      U = !0;
      var u = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      var v;
      v = V.current, V.current = null, Mr();
      try {
        if (e) {
          var c = function() {
            throw Error();
          };
          if (Object.defineProperty(c.prototype, "props", {
            set: function() {
              throw Error();
            }
          }), typeof Reflect == "object" && Reflect.construct) {
            try {
              Reflect.construct(c, []);
            } catch (w) {
              t = w;
            }
            Reflect.construct(r, [], c);
          } else {
            try {
              c.call();
            } catch (w) {
              t = w;
            }
            r.call(c.prototype);
          }
        } else {
          try {
            throw Error();
          } catch (w) {
            t = w;
          }
          r();
        }
      } catch (w) {
        if (w && t && typeof w.stack == "string") {
          for (var f = w.stack.split(`
`), y = t.stack.split(`
`), j = f.length - 1, d = y.length - 1; j >= 1 && d >= 0 && f[j] !== y[d]; )
            d--;
          for (; j >= 1 && d >= 0; j--, d--)
            if (f[j] !== y[d]) {
              if (j !== 1 || d !== 1)
                do
                  if (j--, d--, d < 0 || f[j] !== y[d]) {
                    var b = `
` + f[j].replace(" at new ", " at ");
                    return r.displayName && b.includes("<anonymous>") && (b = b.replace("<anonymous>", r.displayName)), typeof r == "function" && M.set(r, b), b;
                  }
                while (j >= 1 && d >= 0);
              break;
            }
        }
      } finally {
        U = !1, V.current = v, zr(), Error.prepareStackTrace = u;
      }
      var X = r ? r.displayName || r.name : "", Er = X ? I(X) : "";
      return typeof r == "function" && M.set(r, Er), Er;
    }
    function Wr(r, e, a) {
      return ir(r, !1);
    }
    function Vr(r) {
      var e = r.prototype;
      return !!(e && e.isReactComponent);
    }
    function z(r, e, a) {
      if (r == null)
        return "";
      if (typeof r == "function")
        return ir(r, Vr(r));
      if (typeof r == "string")
        return I(r);
      switch (r) {
        case P:
          return I("Suspense");
        case h:
          return I("SuspenseList");
      }
      if (typeof r == "object")
        switch (r.$$typeof) {
          case s:
            return Wr(r.render);
          case E:
            return z(r.type, e, a);
          case T: {
            var t = r, u = t._payload, v = t._init;
            try {
              return z(v(u), e, a);
            } catch {
            }
          }
        }
      return "";
    }
    var N = Object.prototype.hasOwnProperty, ur = {}, vr = S.ReactDebugCurrentFrame;
    function W(r) {
      if (r) {
        var e = r._owner, a = z(r.type, r._source, e ? e.type : null);
        vr.setExtraStackFrame(a);
      } else
        vr.setExtraStackFrame(null);
    }
    function Yr(r, e, a, t, u) {
      {
        var v = Function.call.bind(N);
        for (var c in r)
          if (v(r, c)) {
            var f = void 0;
            try {
              if (typeof r[c] != "function") {
                var y = Error((t || "React class") + ": " + a + " type `" + c + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof r[c] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                throw y.name = "Invariant Violation", y;
              }
              f = r[c](e, c, t, a, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
            } catch (j) {
              f = j;
            }
            f && !(f instanceof Error) && (W(u), m("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", t || "React class", a, c, typeof f), W(null)), f instanceof Error && !(f.message in ur) && (ur[f.message] = !0, W(u), m("Failed %s type: %s", a, f.message), W(null));
          }
      }
    }
    var Ur = Array.isArray;
    function $(r) {
      return Ur(r);
    }
    function $r(r) {
      {
        var e = typeof Symbol == "function" && Symbol.toStringTag, a = e && r[Symbol.toStringTag] || r.constructor.name || "Object";
        return a;
      }
    }
    function Hr(r) {
      try {
        return sr(r), !1;
      } catch {
        return !0;
      }
    }
    function sr(r) {
      return "" + r;
    }
    function jr(r) {
      if (Hr(r))
        return m("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", $r(r)), sr(r);
    }
    var L = S.ReactCurrentOwner, qr = {
      key: !0,
      ref: !0,
      __self: !0,
      __source: !0
    }, dr, pr, H;
    H = {};
    function Gr(r) {
      if (N.call(r, "ref")) {
        var e = Object.getOwnPropertyDescriptor(r, "ref").get;
        if (e && e.isReactWarning)
          return !1;
      }
      return r.ref !== void 0;
    }
    function Br(r) {
      if (N.call(r, "key")) {
        var e = Object.getOwnPropertyDescriptor(r, "key").get;
        if (e && e.isReactWarning)
          return !1;
      }
      return r.key !== void 0;
    }
    function Kr(r, e) {
      if (typeof r.ref == "string" && L.current && e && L.current.stateNode !== e) {
        var a = O(L.current.type);
        H[a] || (m('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', O(L.current.type), r.ref), H[a] = !0);
      }
    }
    function Jr(r, e) {
      {
        var a = function() {
          dr || (dr = !0, m("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", e));
        };
        a.isReactWarning = !0, Object.defineProperty(r, "key", {
          get: a,
          configurable: !0
        });
      }
    }
    function Zr(r, e) {
      {
        var a = function() {
          pr || (pr = !0, m("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", e));
        };
        a.isReactWarning = !0, Object.defineProperty(r, "ref", {
          get: a,
          configurable: !0
        });
      }
    }
    var Qr = function(r, e, a, t, u, v, c) {
      var f = {
        // This tag allows us to uniquely identify this as a React Element
        $$typeof: n,
        // Built-in properties that belong on the element
        type: r,
        key: e,
        ref: a,
        props: c,
        // Record the component responsible for creating this element.
        _owner: v
      };
      return f._store = {}, Object.defineProperty(f._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: !1
      }), Object.defineProperty(f, "_self", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: t
      }), Object.defineProperty(f, "_source", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: u
      }), Object.freeze && (Object.freeze(f.props), Object.freeze(f)), f;
    };
    function re(r, e, a, t, u) {
      {
        var v, c = {}, f = null, y = null;
        a !== void 0 && (jr(a), f = "" + a), Br(e) && (jr(e.key), f = "" + e.key), Gr(e) && (y = e.ref, Kr(e, u));
        for (v in e)
          N.call(e, v) && !qr.hasOwnProperty(v) && (c[v] = e[v]);
        if (r && r.defaultProps) {
          var j = r.defaultProps;
          for (v in j)
            c[v] === void 0 && (c[v] = j[v]);
        }
        if (f || y) {
          var d = typeof r == "function" ? r.displayName || r.name || "Unknown" : r;
          f && Jr(c, d), y && Zr(c, d);
        }
        return Qr(r, f, y, u, t, L.current, c);
      }
    }
    var q = S.ReactCurrentOwner, hr = S.ReactDebugCurrentFrame;
    function C(r) {
      if (r) {
        var e = r._owner, a = z(r.type, r._source, e ? e.type : null);
        hr.setExtraStackFrame(a);
      } else
        hr.setExtraStackFrame(null);
    }
    var G;
    G = !1;
    function B(r) {
      return typeof r == "object" && r !== null && r.$$typeof === n;
    }
    function mr() {
      {
        if (q.current) {
          var r = O(q.current.type);
          if (r)
            return `

Check the render method of \`` + r + "`.";
        }
        return "";
      }
    }
    function ee(r) {
      {
        if (r !== void 0) {
          var e = r.fileName.replace(/^.*[\\\/]/, ""), a = r.lineNumber;
          return `

Check your code at ` + e + ":" + a + ".";
        }
        return "";
      }
    }
    var yr = {};
    function ae(r) {
      {
        var e = mr();
        if (!e) {
          var a = typeof r == "string" ? r : r.displayName || r.name;
          a && (e = `

Check the top-level render call using <` + a + ">.");
        }
        return e;
      }
    }
    function gr(r, e) {
      {
        if (!r._store || r._store.validated || r.key != null)
          return;
        r._store.validated = !0;
        var a = ae(e);
        if (yr[a])
          return;
        yr[a] = !0;
        var t = "";
        r && r._owner && r._owner !== q.current && (t = " It was passed a child from " + O(r._owner.type) + "."), C(r), m('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', a, t), C(null);
      }
    }
    function br(r, e) {
      {
        if (typeof r != "object")
          return;
        if ($(r))
          for (var a = 0; a < r.length; a++) {
            var t = r[a];
            B(t) && gr(t, e);
          }
        else if (B(r))
          r._store && (r._store.validated = !0);
        else if (r) {
          var u = Sr(r);
          if (typeof u == "function" && u !== r.entries)
            for (var v = u.call(r), c; !(c = v.next()).done; )
              B(c.value) && gr(c.value, e);
        }
      }
    }
    function oe(r) {
      {
        var e = r.type;
        if (e == null || typeof e == "string")
          return;
        var a;
        if (typeof e == "function")
          a = e.propTypes;
        else if (typeof e == "object" && (e.$$typeof === s || // Note: Memo only checks outer props here.
        // Inner props are checked in the reconciler.
        e.$$typeof === E))
          a = e.propTypes;
        else
          return;
        if (a) {
          var t = O(e);
          Yr(a, r.props, "prop", t, r);
        } else if (e.PropTypes !== void 0 && !G) {
          G = !0;
          var u = O(e);
          m("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", u || "Unknown");
        }
        typeof e.getDefaultProps == "function" && !e.getDefaultProps.isReactClassApproved && m("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
      }
    }
    function te(r) {
      {
        for (var e = Object.keys(r.props), a = 0; a < e.length; a++) {
          var t = e[a];
          if (t !== "children" && t !== "key") {
            C(r), m("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", t), C(null);
            break;
          }
        }
        r.ref !== null && (C(r), m("Invalid attribute `ref` supplied to `React.Fragment`."), C(null));
      }
    }
    function _r(r, e, a, t, u, v) {
      {
        var c = Fr(r);
        if (!c) {
          var f = "";
          (r === void 0 || typeof r == "object" && r !== null && Object.keys(r).length === 0) && (f += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
          var y = ee(u);
          y ? f += y : f += mr();
          var j;
          r === null ? j = "null" : $(r) ? j = "array" : r !== void 0 && r.$$typeof === n ? (j = "<" + (O(r.type) || "Unknown") + " />", f = " Did you accidentally export a JSX literal instead of a component?") : j = typeof r, m("React.jsx: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", j, f);
        }
        var d = re(r, e, a, u, v);
        if (d == null)
          return d;
        if (c) {
          var b = e.children;
          if (b !== void 0)
            if (t)
              if ($(b)) {
                for (var X = 0; X < b.length; X++)
                  br(b[X], r);
                Object.freeze && Object.freeze(b);
              } else
                m("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
            else
              br(b, r);
        }
        return r === l ? te(d) : oe(d), d;
      }
    }
    function ne(r, e, a) {
      return _r(r, e, a, !0);
    }
    function le(r, e, a) {
      return _r(r, e, a, !1);
    }
    var fe = le, ce = ne;
    A.Fragment = l, A.jsx = fe, A.jsxs = ce;
  }()), A;
}
process.env.NODE_ENV === "production" ? K.exports = ue() : K.exports = ve();
var se = K.exports;
function je(o, n) {
  if (typeof o != "object" || o === null)
    return o;
  var i = o[Symbol.toPrimitive];
  if (i !== void 0) {
    var l = i.call(o, n || "default");
    if (typeof l != "object")
      return l;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (n === "string" ? String : Number)(o);
}
function de(o) {
  var n = je(o, "string");
  return typeof n == "symbol" ? n : String(n);
}
function pe(o, n, i) {
  return n = de(n), n in o ? Object.defineProperty(o, n, {
    value: i,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : o[n] = i, o;
}
function Or(o, n) {
  var i = Object.keys(o);
  if (Object.getOwnPropertySymbols) {
    var l = Object.getOwnPropertySymbols(o);
    n && (l = l.filter(function(p) {
      return Object.getOwnPropertyDescriptor(o, p).enumerable;
    })), i.push.apply(i, l);
  }
  return i;
}
function wr(o) {
  for (var n = 1; n < arguments.length; n++) {
    var i = arguments[n] != null ? arguments[n] : {};
    n % 2 ? Or(Object(i), !0).forEach(function(l) {
      pe(o, l, i[l]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(o, Object.getOwnPropertyDescriptors(i)) : Or(Object(i)).forEach(function(l) {
      Object.defineProperty(o, l, Object.getOwnPropertyDescriptor(i, l));
    });
  }
  return o;
}
var he = (o, n, i) => {
  for (var l of Object.keys(o)) {
    var p;
    if (o[l] !== ((p = n[l]) !== null && p !== void 0 ? p : i[l]))
      return !1;
  }
  return !0;
}, me = (o) => {
  var n = (i) => {
    var l = o.defaultClassName, p = wr(wr({}, o.defaultVariants), i);
    for (var R in p) {
      var _, g = (_ = p[R]) !== null && _ !== void 0 ? _ : o.defaultVariants[R];
      if (g != null) {
        var s = g;
        typeof s == "boolean" && (s = s === !0 ? "true" : "false");
        var P = (
          // @ts-expect-error
          o.variantClassNames[R][s]
        );
        P && (l += " " + P);
      }
    }
    for (var [h, E] of o.compoundVariants)
      he(h, p, o.defaultVariants) && (l += " " + E);
    return l;
  };
  return n.variants = () => Object.keys(o.variantClassNames), n;
}, ye = me({ defaultClassName: "_5hgvyjv", variantClassNames: { font: { system: "_5hgvyj0", inter: "_5hgvyj1", mono: "_5hgvyj2" }, size: { xs: "_5hgvyj3", sm: "_5hgvyj4", md: "_5hgvyj5", lg: "_5hgvyj6", xl: "_5hgvyj7", xxl: "_5hgvyj8", "3xl": "_5hgvyj9", "4xl": "_5hgvyja", "5xl": "_5hgvyjb", "6xl": "_5hgvyjc", "7xl": "_5hgvyjd", "8xl": "_5hgvyje", "9xl": "_5hgvyjf" }, weight: { superlite: "_5hgvyjg", lite: "_5hgvyjh", normal: "_5hgvyji", medium: "_5hgvyjj", semibold: "_5hgvyjk", bold: "_5hgvyjl", heavy: "_5hgvyjm", black: "_5hgvyjn" }, align: { left: "_5hgvyjo", center: "_5hgvyjp", right: "_5hgvyjq" }, casing: { none: "_5hgvyjr", uppercase: "_5hgvyjs", lowercase: "_5hgvyjt", capitalize: "_5hgvyju" } }, defaultVariants: { font: "system", size: "md", weight: "medium", align: "left", casing: "none" }, compoundVariants: [] });
function Tr(o) {
  var n, i, l = "";
  if (typeof o == "string" || typeof o == "number")
    l += o;
  else if (typeof o == "object")
    if (Array.isArray(o))
      for (n = 0; n < o.length; n++)
        o[n] && (i = Tr(o[n])) && (l && (l += " "), l += i);
    else
      for (n in o)
        o[n] && (l && (l += " "), l += n);
  return l;
}
function ge() {
  for (var o, n, i = 0, l = ""; i < arguments.length; )
    (o = arguments[i++]) && (n = Tr(o)) && (l && (l += " "), l += n);
  return l;
}
const be = J.forwardRef(
  ({
    children: o,
    className: n,
    font: i = "inter",
    size: l = "md",
    align: p = "left",
    weight: R = "medium",
    casing: _,
    ...g
  }, s) => /* @__PURE__ */ se.jsx(
    "p",
    {
      ref: s,
      className: ge(n, ye({ font: i, size: l, align: p, weight: R, casing: _ })),
      ...g,
      children: o
    }
  )
);
be.displayName = "Text";
export {
  be as Text,
  Ee as kit
};
//# sourceMappingURL=index.mjs.map
