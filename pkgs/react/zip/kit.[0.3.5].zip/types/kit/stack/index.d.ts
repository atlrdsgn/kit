export { Stack, type Direction, type Wrap } from './stack';
//# sourceMappingURL=index.d.ts.map