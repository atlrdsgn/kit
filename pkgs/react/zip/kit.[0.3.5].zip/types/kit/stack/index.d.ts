export { Stack } from './stack';
//# sourceMappingURL=index.d.ts.map