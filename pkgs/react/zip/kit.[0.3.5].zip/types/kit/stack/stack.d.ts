import * as React from 'react';
import { OptionalResponsiveObject, OptionalResponsiveValue } from '../../lib/css';
import { ReactNodeNoStrings } from '../_shared/types';
import { type DivProps } from '../rect';
export type Direction = 'horizontal' | 'vertical';
export type Wrap = 1 | 0;
export declare const directionToFlexDirection: (direction: OptionalResponsiveValue<Direction> | undefined) => "column" | "row" | Partial<Record<string, "column" | "row">> | undefined;
export declare const wrapToFlexWrap: (wrap: OptionalResponsiveObject<true | false> | undefined) => "nowrap" | "wrap" | Partial<Record<string, "nowrap" | "wrap">> | undefined;
/** ------------------------------------------- */
export declare const validStackComponents: readonly ["a", "article", "div", "form", "header", "label", "li", "main", "section", "span"];
type Props = {
    as?: (typeof validStackComponents)[number];
    align?: DivProps['alignItems'];
    children: ReactNodeNoStrings;
    direction?: OptionalResponsiveValue<Direction>;
    flex?: DivProps['flex'];
    justify?: DivProps['justifyContent'];
    space?: DivProps['gap'];
    wrap?: OptionalResponsiveObject<true | false>;
};
export declare const Stack: ({ as, align, children, justify, flex, direction, space, wrap, }: React.PropsWithChildren<Props>) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=stack.d.ts.map