import React from 'react';
import type { TextFontVariants, TextSizeVariants, TextAlignVariants, TextWeightVariants, TextCasingVariants, TextVariantProps } from './text.css';
interface BASE_TEXT_PROPS {
    children?: React.ReactNode;
    className?: string;
    font?: TextFontVariants;
    size?: TextSizeVariants;
    align?: TextAlignVariants;
    weight?: TextWeightVariants;
    casing?: TextCasingVariants;
}
export type TextProps = BASE_TEXT_PROPS & TextVariantProps & React.HTMLAttributes<HTMLParagraphElement>;
export declare const Text: React.ForwardRefExoticComponent<BASE_TEXT_PROPS & {
    font?: "system" | "mono" | "inter" | undefined;
    size?: "xs" | "sm" | "md" | "lg" | "xl" | "xxl" | "3xl" | "4xl" | "5xl" | "6xl" | "7xl" | "8xl" | "9xl" | undefined;
    weight?: "medium" | "black" | "normal" | "bold" | "superlite" | "lite" | "semibold" | "heavy" | undefined;
    align?: "left" | "right" | "center" | undefined;
    casing?: "none" | "capitalize" | "lowercase" | "uppercase" | undefined;
} & React.HTMLAttributes<HTMLParagraphElement> & React.RefAttributes<HTMLParagraphElement>>;
export {};
//# sourceMappingURL=text.d.ts.map