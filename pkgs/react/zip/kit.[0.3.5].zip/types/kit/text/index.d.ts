export * from './text';
//# sourceMappingURL=index.d.ts.map