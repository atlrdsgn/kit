import { RecipeVariants } from '@vanilla-extract/recipes';
/** ---------------------------------------------------------- */
declare const font: Record<"system" | "mono" | "inter", string>;
declare const size: Record<"xs" | "sm" | "md" | "lg" | "xl" | "xxl" | "3xl" | "4xl" | "5xl" | "6xl" | "7xl" | "8xl" | "9xl", string>;
declare const weight: Record<"medium" | "black" | "normal" | "bold" | "superlite" | "lite" | "semibold" | "heavy", string>;
declare const align: Record<"left" | "right" | "center", string>;
declare const casing: Record<"none" | "capitalize" | "lowercase" | "uppercase", string>;
export type TextFontVariants = keyof typeof font;
export type TextSizeVariants = keyof typeof size;
export type TextWeightVariants = keyof typeof weight;
export type TextAlignVariants = keyof typeof align;
export type TextCasingVariants = keyof typeof casing;
/**
 * The `text` recipe combines the `font`, `size`, `weight`, `color`, and `align` style variants
 * into a single CSS rule, with default values set.
 *
 * Usage:
 *
 * <Text font="system" size="md" weight="medium" color="slate5" align="left" />
 * (or)
 * `className={text({ font: 'system', size: 'md', weight: 'medium', color: 'slate5', align: 'left' })}`
 */
export type TextVariantProps = RecipeVariants<typeof text>;
export declare const text: import("@vanilla-extract/recipes").RuntimeFn<{
    font: Record<"system" | "mono" | "inter", string>;
    size: Record<"xs" | "sm" | "md" | "lg" | "xl" | "xxl" | "3xl" | "4xl" | "5xl" | "6xl" | "7xl" | "8xl" | "9xl", string>;
    weight: Record<"medium" | "black" | "normal" | "bold" | "superlite" | "lite" | "semibold" | "heavy", string>;
    align: Record<"left" | "right" | "center", string>;
    casing: Record<"none" | "capitalize" | "lowercase" | "uppercase", string>;
}>;
export {};
//# sourceMappingURL=text.css.d.ts.map