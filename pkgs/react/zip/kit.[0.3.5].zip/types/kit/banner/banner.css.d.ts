import { RuntimeFn, type RecipeVariants } from '@vanilla-extract/recipes';
declare const colorKeys: ("one" | "two")[];
declare const sizeKeys: ("small" | "medium" | "large")[];
declare const borderKeys: "true"[];
/** ------------------------------------------------------- */
export type BannerSize = typeof sizeKeys;
export type BannerBorderBoolean = typeof borderKeys;
export type BannerVariant = typeof colorKeys;
export type BannerVariants = RecipeVariants<typeof banner>;
export declare const banner: RuntimeFn<{
    size: Record<"small" | "medium" | "large", string>;
    border: Record<"true", string>;
    variant: Record<"one" | "two", string>;
}>;
export {};
//# sourceMappingURL=banner.css.d.ts.map