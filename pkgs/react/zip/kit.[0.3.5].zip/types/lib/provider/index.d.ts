export { KitProvider, type KitProviderProps } from './provider';
export { KitContext, useTheme, type KitContextValue, type KitMode } from './context';
//# sourceMappingURL=index.d.ts.map