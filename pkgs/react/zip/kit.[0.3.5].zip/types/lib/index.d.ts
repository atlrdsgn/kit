export { kit } from './theme/kit.css';
//# sourceMappingURL=index.d.ts.map