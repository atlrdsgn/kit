export { Space, type SpaceProps } from './space';
//# sourceMappingURL=index.d.ts.map