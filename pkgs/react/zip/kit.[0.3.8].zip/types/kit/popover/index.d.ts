export { Popover, type PopoverProps } from './popover';
//# sourceMappingURL=index.d.ts.map