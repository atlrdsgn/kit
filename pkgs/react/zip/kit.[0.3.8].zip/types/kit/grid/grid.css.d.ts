export declare const gridItemMinWidth: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
export declare const gridMaxRowItems: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
export declare const grid: string;
//# sourceMappingURL=grid.css.d.ts.map