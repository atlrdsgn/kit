export declare const canvas: string;
export declare const canvas_blur: string;
//# sourceMappingURL=canvas.css.d.ts.map