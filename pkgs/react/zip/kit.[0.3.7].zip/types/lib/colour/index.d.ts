export { type KitColours, kitColour, darkKitColour } from './system';
//# sourceMappingURL=index.d.ts.map